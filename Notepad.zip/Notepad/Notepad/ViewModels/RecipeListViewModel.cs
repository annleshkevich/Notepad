﻿using Notepad.Data.Models;

namespace Notepad.ViewModels
{
    public class RecipeListViewModel
    {
        public IEnumerable<Recipe> allRecipes { get; set; }
        
    }
}
